package fields;

import abilities.Ability;

public abstract class Field {
    public abstract void accept(Ability a);
}
