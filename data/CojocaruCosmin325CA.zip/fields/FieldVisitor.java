package fields;

public interface FieldVisitor {
        void visitField(Land field);
        void visitField(Volcanic field);
        void visitField(Desert field);
        void visitField(Woods field);
}
