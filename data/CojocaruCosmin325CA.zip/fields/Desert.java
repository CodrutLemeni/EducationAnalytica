package fields;

import abilities.Ability;

public class Desert extends Field {
    public void accept(Ability a) {
        a.visitField(this);
    }

}
