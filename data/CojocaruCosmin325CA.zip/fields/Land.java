package fields;

import abilities.Ability;

public class Land extends Field {

    public void accept(Ability a) {
        a.visitField(this);
    }
}
