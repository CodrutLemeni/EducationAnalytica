package fields;

import abilities.Ability;

public class Woods extends Field {
    public void accept(Ability a) {
        a.visitField(this);
    }
}
