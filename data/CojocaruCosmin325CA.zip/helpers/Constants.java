package helpers;

public final class Constants {
//    public static final float ROGUE_MODIFIER_FIREBLAST = -0.2f;
//    public static final float KNIGHT_MODIFIER_FIREBLAST = 0.2f;
//    public static final float PYROMANCER_MODIFIER_FIREBLAST = -0.1f;
//    public static final float WIZARD_MODIFIER_FIRBLAST = 0.05f;
//    public static final float ROGUE_MODIFIER_IGNITE = -0.2f;
//    public static final float KNIGHT_MODIFIER_IGNITE = 0.2f;
//    public static final float PYROMANCER_MODIFIER_IGNITE = -0.1f;
//    public static final float WIZARD_MODIFIER_IGNITE = 0.05f;
//    public static final int IGNITE_ROUNDS_OVERTIME = 2;
//    public static final int IGNITE_BASE_DMG = 150;
//    public static final int IGNITE_BASE_OVERTIME = 50;
//    public static final int FIREBLAST_INCREASE = 50;
//    public static final int IGNITE_BASE_INCREASE = 20;
//    public static final int IGNITE_OVERTIME_INCREASE = 30;
//    public static final int FIREBLAST_BASE_DMG = 350;
    public static final int ROGUE_INITIAL_HP = 600;
    public static final int ROGUE_HP_INCREASE = 40;
    public static final int KNIGHT_INITIAL_HP = 900;
    public static final int KNIGHT_HP_INCREASE = 80;
    public static final int PYROMANCER_INITIAL_HP = 500;
    public static final int PYROMANCER_HP_INCREASE = 50;
    public static final int WIZARD_INITIAL_HP = 400;
    public static final int WIZARD_HP_INCREASE = 30;
    public static final int INITIAL_XP = 0;



}
