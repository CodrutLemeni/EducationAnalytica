package players;

import abilities.Ability;

public class Pyromancer extends Player {

    public Pyromancer(int HP, int XP, int lvl, int bonusHpLvl, int x, int y) {
        super(HP, XP, lvl, bonusHpLvl, x, y);
    }

    public void accept(Ability a) {
        a.visit(this);
    }

    @Override
    public String toString() {
        if(this.getHP() > 0) {
            return "P " + this.getLvl() + " " + this.getXP() + " " +
                    this.getHP() + " " + this.getX() + " " + this.getY();
        }
        else {
            return "P" + " dead";
        }
    }
    public void print() {
        if(this.getHP() > 0) {
            System.out.println("P " + this.getLvl() + " " + this.getXP() + " " +
                    this.getHP() + " " + this.getX() + " " + this.getY());
        }
        else {
            System.out.println("P" + " dead");
        }
    }
}
