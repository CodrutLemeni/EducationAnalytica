package players;

import abilities.Ability;

public class Rogue extends Player {

    public Rogue(int HP, int XP, int lvl, int bonusHpLvl, int x, int y) {
        super(HP, XP, lvl, bonusHpLvl, x, y);
    }

    public void accept(Ability a) {
        a.visit(this);
    }
    @Override
    public String toString() {
        if(this.getHP() > 0) {
            return "R " + this.getLvl() + " " + this.getXP() + " " +
                    this.getHP() + " " + this.getX() + " " + this.getY();
        }
        else {
            return "R" + " dead";
        }
    }
    public void print() {
        if(this.getHP() > 0) {
            System.out.println("R " + this.getLvl() + " " + this.getXP() + " " +
                    this.getHP() + " " + this.getX() + " " + this.getY());
        }
        else {
            System.out.println("R" + " dead");
        }
    }
}
