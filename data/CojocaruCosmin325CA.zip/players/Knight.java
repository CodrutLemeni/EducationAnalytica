package players;

import abilities.Ability;

public class Knight extends Player {

    public Knight(int HP, int XP, int lvl, int bonusHpLvl, int x, int y) {
        super(HP, XP, lvl, bonusHpLvl, x, y);
    }

    @Override
    public String toString() {
        if(this.getHP() > 0) {
           return "K " + this.getLvl() + " " + this.getXP() + " " +
                    this.getHP() + " " + this.getX() + " " + this.getY();
        }
        else {
            return "K" + " dead";
        }
    }

    public void accept(Ability a) {
        a.visit(this);
    }


    public void print() {
        if(this.getHP() > 0) {
            System.out.println("K " + this.getLvl() + " " + this.getXP() + " " +
                    this.getHP() + " " + this.getX() + " " + this.getY());
        }
        else {
            System.out.println("K" + " dead");
        }
    }
}
