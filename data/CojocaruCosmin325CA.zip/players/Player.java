package players;

import abilities.Ability;

import java.util.Scanner;

public class Player {
    private int HP;
    private int XP;
    private int lvl;
    private int bonusHpLvl;
    private int X;
    private int Y;
    private boolean canMove;
    private int dmgOvertime;
    private int roundsOvertime;
    private int initialHp;
    private int unracistDamageReceived;
    private int unmovedRounds;
    private int moveIdx;
    private Ability firstAbility;
    private Ability secondAbility;
    private StringBuilder moves = new StringBuilder();
    public Player(final int HP, final int XP, final int lvl, final int bonusHpLvl, final int x, final int y) {
        this.HP = HP;
        this.XP = XP;
        this.lvl = lvl;
        this.bonusHpLvl = bonusHpLvl;
        this.initialHp = HP;
        this.canMove = true;
        X = x;
        Y = y;
        this.moveIdx = 0;
    }

    @Override
    public String toString() {
        return "player";
    }
    public void accept(Ability a) {

    }

    public int xpForLevelup() {
        return 250 + this.lvl * 50;
    }

    public int getUnracistDamageReceived() {
        return unracistDamageReceived;
    }

    public int getUnmovedRounds() {
        return unmovedRounds;
    }

    public void setUnmovedRounds(final int unmovedRounds) {
        this.unmovedRounds = unmovedRounds;
    }

    public void setUnracistDamageReceived(final int unracistDamageReceived) {
        this.unracistDamageReceived += unracistDamageReceived;
    }

    public int getMaxHp() {
        return (initialHp + lvl * bonusHpLvl);
    }

    public Ability getFirstAbility() {
        return firstAbility;
    }

    public void setFirstAbility(final Ability firstAbility) {
        this.firstAbility = firstAbility;
    }

    public Ability getSecondAbility() {
        return secondAbility;
    }

    public void setSecondAbility(final Ability secondAbility) {
        this.secondAbility = secondAbility;
    }

    public int getDmgOvertime() {
        return dmgOvertime;
    }

    public void setDmgOvertime(final int dmgOvertime) {
        this.dmgOvertime = dmgOvertime;
    }

    public int getRoundsOvertime() {
        return roundsOvertime;
    }

    public void setRoundsOvertime(final int roundsOvertime) {
        this.roundsOvertime = roundsOvertime;
    }

    public int getHP() {
        return HP;
    }

    public void setHP(final int HP) {
        this.HP = HP;
    }

    public int getXP() {
        return XP;
    }

    public void setXP(int XP) {
        this.XP = XP;
    }

    public int getLvl() {
        return lvl;
    }

    public void setLvl(int lvl) {
        this.lvl = lvl;
    }

    public int getBonusHpLvl() {
        return bonusHpLvl;
    }

    public void setBonusHpLvl(int bonusHpLvl) {
        this.bonusHpLvl = bonusHpLvl;
    }

    public int getX() {
        return X;
    }

    public void setX(int x) {
        X = x;
    }

    public int getY() {
        return Y;
    }

    public void setY(int y) {
        Y = y;
    }

    public boolean canMove() {
        return canMove;
    }

    public void setCanMove(boolean canMove) {
        this.canMove = canMove;
    }

    public StringBuilder getMoves() {
        return moves;
    }

    public void setMoves(StringBuilder moves) {
        this.moves = moves;
    }

    public void print() {

    }

}
