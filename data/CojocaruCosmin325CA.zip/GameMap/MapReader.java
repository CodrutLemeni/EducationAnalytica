package GameMap;

import abilities.AbilitiesFactory;
import fields.Desert;
import fields.Land;
import fields.Volcanic;
import fields.Woods;
import helpers.Constants;
import players.*;

import java.io.*;
import java.util.Scanner;

public class MapReader {
    private Scanner in;
    private Scanner out1;
    private SummonersRift map;

    public MapReader(SummonersRift map, String input) throws IOException {
        this.map = map;
        File citire = new File(input);
        this.in = new Scanner(citire);

    }
    public void readDimensions() {
        int x = in.nextInt();
        int y = in.nextInt();
        map.setWidth(y);
        map.setHeight(x);
    }

    public void readMapContent() {
        String line = in.nextLine();
        for (int i = 0; i < map.getHeight(); i++) {
            line = in.nextLine();
            for (int j = 0; j < map.getWidth(); j++) {
                char c = line.charAt(j);
                if (c == 'W') {
                    map.setWoodsCell(i, j, new Woods());
                } else if (c == 'D') {
                    map.setDesertCell(i, j, new Desert());
                } else if (c == 'L') {
                    map.setLandCell(i, j, new Land());
                } else if (c == 'V') {
                    map.setVolcanicCell(i, j, new Volcanic());
                }
            }
        }
    }

    public void readSummoners(AbilitiesFactory factory) {
        int nr = in.nextInt();
        map.setNoPlayers(nr);
        for (int i = 0; i < nr; i++) {
            char c = in.next().charAt(0);
            int x = in.nextInt();
            int y = in.nextInt();
            if (c == 'R') {
                Player p = new Rogue(Constants.ROGUE_INITIAL_HP, 0, 0,
                        Constants.ROGUE_HP_INCREASE, x, y);
                p.setFirstAbility(factory.getAbility("Backstab", p));
                p.setSecondAbility(factory.getAbility("Paralysis", p));
                map.getPlayers().add(p);
            } else if (c == 'K') {
                Player p = new Knight(Constants.KNIGHT_INITIAL_HP, 0, 0,
                        Constants.KNIGHT_HP_INCREASE, x, y);
                p.setFirstAbility(factory.getAbility("Execute", p));
                p.setSecondAbility(factory.getAbility("Slam", p));
                map.getPlayers().add(p);
            } else if (c == 'W') {
                Player p = new Wizard(Constants.WIZARD_INITIAL_HP, 0, 0,
                        Constants.WIZARD_HP_INCREASE, x, y);
                p.setFirstAbility(factory.getAbility("Drain", p));
                p.setSecondAbility(factory.getAbility("Deflect", p));
                map.getPlayers().add(p);
            } else if (c == 'P') {
                Player p = new Pyromancer(Constants.PYROMANCER_INITIAL_HP, 0, 0,
                        Constants.PYROMANCER_HP_INCREASE, x, y);
                p.setFirstAbility(factory.getAbility("Fireblast", p));
                p.setSecondAbility(factory.getAbility("Ignite", p));
                map.getPlayers().add(p);
            }
        }
    }

    public void readMoves() {
        int nr = in.nextInt();
        map.setNoRounds(nr);
        String line = in.nextLine();
        for (int i = 0; i < nr; i++) {
            line = in.nextLine();
            for (int j = 0; j < line.length(); j++) {
                map.getPlayers().get(j).getMoves().append(line.charAt(j));
            }
        }
    }
}
