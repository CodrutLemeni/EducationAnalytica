package GameMap;

import fields.Field;
import players.Player;

import java.util.ArrayList;

public class RoundSimulator {
    SummonersRift terrain;

    public RoundSimulator(SummonersRift terrain) {
        this.terrain = terrain;
    }

    public void run(int idx) {
        damageOvertime();
        movePlayers(idx);
        getFieldsBonuses();
        solveConflicts();
        increaseLvl();

        resetFields();
    }

    public void movePlayers(int idx) {
        for (Player p : terrain.getPlayers()) {
            char move = p.getMoves().charAt(idx);
            if (move == '_') {
                continue;
            } else if (move == 'U' && p.canMove() && p.getHP() > 0) {
                p.setX(p.getX() - 1);
            } else if (move == 'D' && p.canMove() && p.getHP() > 0) {
                p.setX(p.getX() + 1);
            } else if (move == 'L' && p.canMove() && p.getHP() > 0) {
                p.setY(p.getY() - 1);
            } else if (move == 'R' && p.canMove() && p.getHP() > 0) {
                p.setY(p.getY() + 1);
            }
        }
    }

    public void getFieldsBonuses() {
        for (Player p : terrain.getPlayers()) {
            Field f = terrain.getCell(p.getX(), p.getY());
            f.accept(p.getFirstAbility());
            f.accept(p.getSecondAbility());
        }
    }

    public void solveConflicts() {
        ArrayList<Player> players = terrain.getPlayers();
        for (int i = 0; i < players.size(); i++) {
            if (players.get(i).getHP() <= 0) {
                continue;
            }
            for (int j = i + 1; j < players.size(); j++) {
                if (players.get(i) == players.get(j) || players.get(j).getHP() <= 0) {
                    continue;
                }
                Player p1 = players.get(i);
                Player p2 = players.get(j);
                if (calculateOvertime(p1, p2)) {
                    continue;
                }
                if (p1.getX() == p2.getX() && p1.getY() == p2.getY()) {
                    p2.accept(p1.getFirstAbility());
                    p2.accept(p1.getSecondAbility());
                    p1.accept(p2.getFirstAbility());
                    p1.accept(p2.getSecondAbility());
                    if (p1.getHP() <= 0) {
                        p2.setXP(p2.getXP() + Math.max(0, 200 - (p2.getLvl() - p1.getLvl()) * 40));
                    }
                    if (p2.getHP() <= 0) {
                        p1.setXP(p1.getXP() + Math.max(0, 200 - (p1.getLvl() - p2.getLvl()) * 40));
                    }
                }
            }
        }
    }

    public boolean calculateOvertime(Player p1, Player p2) {
        boolean ok = false;
        if (p1.getHP() <= 0) {
            ok = true;
        } else if (p2.getHP() <= 0) {
            ok = true;
        }
        return ok;
    }

    public void damageOvertime() {
        for (Player p : terrain.getPlayers()) {
            if (p.getRoundsOvertime() > 0) {
                p.setRoundsOvertime(p.getRoundsOvertime() - 1);
                p.setHP(p.getHP() - p.getDmgOvertime());
            }

            if (p.getUnmovedRounds() > 0) {
                p.setUnmovedRounds(p.getUnmovedRounds() - 1);
            }
            else if (p.getUnmovedRounds() == 0) {
                p.setCanMove(true);
            }
        }
    }

    public void increaseLvl() {
        for (Player p : terrain.getPlayers()) {
            if (p.getHP() <= 0) {
                continue;
            }
            while (p.getXP() >= p.xpForLevelup()) {
                p.setLvl(p.getLvl() + 1);
                p.setHP(p.getMaxHp());
                p.getFirstAbility().levelUp();
                p.getSecondAbility().levelUp();
            }
        }
    }

    public void resetFields() {
        for (Player p : terrain.getPlayers()) {
            p.getFirstAbility().reset();
            p.getSecondAbility().reset();
        }
    }
}
