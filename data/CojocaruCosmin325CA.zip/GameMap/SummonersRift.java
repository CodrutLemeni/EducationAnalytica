package GameMap;

import abilities.AbilitiesFactory;
import fields.*;
import players.Player;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class SummonersRift {
    private int height;
    private int width;
    private int noPlayers;
    private int noRounds;
    Field map[][];
    MapReader mapReader;
    ArrayList<Player> players;
    AbilitiesFactory factory;
    BufferedWriter out;

    public SummonersRift(String input, String output) throws IOException {
        players = new ArrayList<>();
        factory = AbilitiesFactory.getInstance();
        File afisare = new File(output);
        out = new BufferedWriter(new FileWriter(afisare));
        mapReader = new MapReader(this, input);
    }

    public void setup() {
        mapReader.readDimensions();
        createFieldMatrix();
        mapReader.readMapContent();
        mapReader.readSummoners(factory);
        mapReader.readMoves();
    }

    public void printPlayers() throws IOException {
        for (Player p : players) {
            out.write(p.toString());
            out.write('\n');
            System.out.println(p.toString());
        }
        out.close();
    }

    public Field getCell(final int x, final int y) {
        return map[x][y];
    }

    public void createFieldMatrix() {
        map = new Field[height][width];
    }

    public void setWoodsCell(final int x, final int y, final Woods f) {
        map[x][y] =  f;
    }

    public void setVolcanicCell(final int x, final int y, final Volcanic f) {
        map[x][y] =  f;
    }

    public void setDesertCell(final int x, final int y, final Desert f) {
        map[x][y] =  f;
    }

    public void setLandCell(final int x, final int y, final Land f) {
        map[x][y] =  f;
    }

    public int getNoPlayers() {
        return noPlayers;
    }

    public ArrayList<Player> getPlayers() {
        return players;
    }

    public void setPlayers(ArrayList<Player> players) {
        this.players = players;
    }

    public void setNoPlayers(int noPlayers) {
        this.noPlayers = noPlayers;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public Field[][] getMap() {
        return map;
    }

    public void setMap(Field[][] map) {
        this.map = map;
    }

    public int getNoRounds() {
        return noRounds;
    }

    public void setNoRounds(int noRounds) {
        this.noRounds = noRounds;
    }



}
