package main;

import GameMap.RoundSimulator;
import GameMap.SummonersRift;
import abilities.Ability;
import abilities.Fireblast;
import players.Player;
import players.Rogue;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        String s1 = args[0];
        String s2 = args[1];
        SummonersRift terrain = new SummonersRift(s1, s2);
        RoundSimulator gameSimulator = new RoundSimulator(terrain);
        terrain.setup();
        for (int i = 0; i < terrain.getNoRounds(); i++) {
            gameSimulator.run(i);
        }
        //gameSimulator.damageOvertime();
        terrain.printPlayers();
    }
}
