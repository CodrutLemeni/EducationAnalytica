package abilities;

import fields.*;
import players.*;

public class Drain extends Ability {
    private float hpPercent;
    private float hpPercentIncrease;
    private float opponentHpPercent;
    private Player player;

    public Drain(final Player p, final float rogueModifier, final float knightModifier,
                     final float pyromancerModifier, final float wizardModifier,
                     final float hpPercent, final float hpPercentIncrease, final float opponentHpPercent) {

        super(0, 0);
        this.rogueModifier = rogueModifier;
        this.knightModifier = knightModifier;
        this.pyromancerModifier = pyromancerModifier;
        this.wizardModifier = wizardModifier;
        this.fieldModifier = 1.0f;
        this.hpPercent = hpPercent;
        this.hpPercentIncrease = hpPercentIncrease;
        this.opponentHpPercent = opponentHpPercent;
        this.player = p;
    }

    @Override
    public void visit(final Rogue target) {
        int hpDmg = Math.round(Math.round(hpPercent *
                Math.min(opponentHpPercent * target.getMaxHp(), target.getHP())) * fieldModifier * rogueModifier);
        target.setHP(target.getHP() - hpDmg);
        }

    @Override
    public void visit(final Knight target) {
        int hpDmg = Math.round(Math.round(hpPercent *
                Math.min(opponentHpPercent * target.getMaxHp(), target.getHP())) * fieldModifier * knightModifier);
        target.setHP(target.getHP() - hpDmg);
    }

    @Override
    public void visit(final Pyromancer target) {
        int hpDmg = Math.round(Math.round(hpPercent *
                Math.min(opponentHpPercent * target.getMaxHp(), target.getHP())) * fieldModifier * pyromancerModifier);
        target.setHP(target.getHP() - hpDmg);
    }

    @Override
    public void visit(final Wizard target) {
        int hpDmg = Math.round(Math.round(hpPercent *
                Math.min(opponentHpPercent * target.getMaxHp(), target.getHP())) * fieldModifier * wizardModifier);
        target.setHP(target.getHP() - hpDmg);
    }

    public void levelUp() {
        this.hpPercent += hpPercentIncrease;
    }

    public float getFieldModifier() {
        return this.fieldModifier;
    }

    public void reset() {
            this.fieldModifier = 1.0f;
    }

    @Override
    public void visitField(final Land field) {
        this.fieldModifier = 1.0f;
    }

    @Override
    public void visitField(final Volcanic field) {
        this.fieldModifier = 1.0f;
    }

    @Override
    public void visitField(final Desert field) {
        this.fieldModifier = 1.10f;
    }

    @Override
    public void visitField(final Woods field) {
        this.fieldModifier = 1.0f;
    }

}
