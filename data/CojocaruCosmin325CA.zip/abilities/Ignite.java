package abilities;

import fields.*;
import helpers.Constants;
import players.*;

public class Ignite extends Ability {
    private int overtimeDmg;
    private int overtimeRounds;
    private int overtimeIncrease;
    private float fieldModifier;
    private Player player;


    public Ignite(final Player p, final float rogueModifier, final float knightModifier,
                  final float pyromancerModifier, final float wizardModifier,
                  final int baseDmg, final int baseIncrease,
                  final int overtimeDmg, final int overtimeIncrease,
                  final int overtimeRounds
                  ) {
        super(baseDmg, baseIncrease);
        this.rogueModifier = rogueModifier;
        this.knightModifier = knightModifier;
        this.pyromancerModifier = pyromancerModifier;
        this.wizardModifier = wizardModifier;
        this.overtimeDmg = overtimeDmg;
        this.overtimeRounds = overtimeRounds;
        this.overtimeIncrease = overtimeIncrease;
        this.fieldModifier = 1.0f;
        this.player = p;
    }

    @Override
    public void visit(final Rogue target) {
        int dmg = Math.round(baseDmg * fieldModifier * rogueModifier);
        target.setHP(target.getHP() - dmg);
        int overtimeDamage = Math.round(overtimeDmg * fieldModifier * rogueModifier);
        target.setDmgOvertime(overtimeDamage);
        target.setRoundsOvertime(overtimeRounds);
        target.setUnmovedRounds(0);

    }

    @Override
    public void visit(final Knight target) {
        int dmg = Math.round(baseDmg * fieldModifier * knightModifier);
        target.setHP(target.getHP() - dmg);
        int overtimeDamage = Math.round(overtimeDmg * fieldModifier * knightModifier);
        target.setDmgOvertime(overtimeDamage);
        target.setRoundsOvertime(overtimeRounds);
        target.setUnmovedRounds(0);
    }

    @Override
    public void visit(final Pyromancer target) {
        int dmg = Math.round(baseDmg * fieldModifier * pyromancerModifier);
        target.setHP(target.getHP() - dmg);
        int overtimeDamage = Math.round(overtimeDmg * fieldModifier * pyromancerModifier);
        target.setDmgOvertime(overtimeDamage);
        target.setRoundsOvertime(overtimeRounds);
        target.setUnmovedRounds(0);
    }

    @Override
    public void visit(final Wizard target) {
        int dmg = Math.round(baseDmg * fieldModifier * wizardModifier);
        target.setHP(target.getHP() - dmg);
        target.setUnracistDamageReceived(Math.round(baseDmg * fieldModifier));
        int overtimeDamage = Math.round(overtimeDmg * fieldModifier * wizardModifier);
        target.setDmgOvertime(overtimeDamage);
        target.setRoundsOvertime(overtimeRounds);
        target.setUnmovedRounds(0);
    }

    @Override
    public int getOvertimeRounds() {
        return overtimeRounds;
    }

    public void levelUp() {
        this.baseDmg += baseIncrease;
        this.overtimeDmg += overtimeIncrease;
    }
    public float getFieldModifier() {
        return this.fieldModifier;
    }

    public void reset() {
        this.fieldModifier = 1.0f;
    }

    @Override
    public int getOvertimeDmg() {
        return overtimeDmg;
    }

    @Override
    public void visitField(final Land field) {
        this.fieldModifier = 1.0f;
    }

    @Override
    public void visitField(final Volcanic field) {
        fieldModifier = 1.25f;
    }

    @Override
    public void visitField(final Desert field) {
        this.fieldModifier = 1.0f;
    }

    @Override
    public void visitField(final Woods field) {
        this.fieldModifier = 1.0f;
    }
}
