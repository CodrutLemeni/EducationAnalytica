package abilities;

import fields.*;
import players.*;

public class Slam extends Ability {
    private Player player;
    public Slam(final Player p, final float rogueModifier, final float knightModifier,
                final float pyromancerModifier, final float wizardModifier,
                final int baseDmg, final int baseIncrease) {
        super(baseDmg, baseIncrease);
        this.rogueModifier = rogueModifier;
        this.knightModifier = knightModifier;
        this.pyromancerModifier = pyromancerModifier;
        this.wizardModifier = wizardModifier;
        this.fieldModifier = 1.0f;
        this.player = p;
    }

    @Override
    public void visit(final Rogue target) {
        int dmg = Math.round(baseDmg * fieldModifier * rogueModifier);
        target.setHP(target.getHP() - dmg);
        target.setUnracistDamageReceived(Math.round(baseDmg * fieldModifier));
        target.setCanMove(false);
        target.setDmgOvertime(0);
        target.setRoundsOvertime(0);
        target.setUnmovedRounds(1);
    }

    @Override
    public void visit(final Knight target) {
        int dmg = Math.round(baseDmg * fieldModifier * knightModifier);
        target.setHP(target.getHP() - dmg);
        target.setUnracistDamageReceived(Math.round(baseDmg * fieldModifier));
        target.setDmgOvertime(0);
        target.setCanMove(false);
        target.setRoundsOvertime(0);
        target.setUnmovedRounds(1);
    }

    @Override
    public void visit(final Pyromancer target) {
        if (target.getHP() <= 0) {
            return;
        }
        int dmg = Math.round(baseDmg * fieldModifier * pyromancerModifier);
        target.setHP(target.getHP() - dmg);
        target.setUnracistDamageReceived(Math.round(baseDmg * fieldModifier));
        target.setDmgOvertime(0);
        target.setCanMove(false);
        target.setRoundsOvertime(0);
        target.setUnmovedRounds(1);
    }

    @Override
    public void visit(final Wizard target) {
        int dmg = Math.round(baseDmg * fieldModifier * wizardModifier);
        target.setHP(target.getHP() - dmg);
        target.setUnracistDamageReceived(Math.round(baseDmg * fieldModifier));
        target.setDmgOvertime(0);
        target.setCanMove(false);
        target.setRoundsOvertime(0);
        target.setUnmovedRounds(1);
    }

    public void levelUp() {
        this.baseDmg += baseIncrease;
    }

    public float getFieldModifier() {
        return this.fieldModifier;
    }

    public void reset() {
        this.fieldModifier = 1.0f;
    }

    @Override
    public void visitField(final Land field) {
        fieldModifier = 1.15f;
    }

    @Override
    public void visitField(final Volcanic field) {
        this.fieldModifier = 1.0f;
    }

    @Override
    public void visitField(final Desert field) {
        this.fieldModifier = 1.0f;
    }

    @Override
    public void visitField(final Woods field) {
        this.fieldModifier = 1.0f;
    }
}
