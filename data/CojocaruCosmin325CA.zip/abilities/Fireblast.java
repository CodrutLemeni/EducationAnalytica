package abilities;

import fields.Desert;
import fields.Land;
import fields.Volcanic;
import fields.Woods;
import players.*;

public class Fireblast extends Ability {
    private Player player;

    public Fireblast(final Player p, final float rogueModifier, final float knightModifier,
                final float pyromancerModifier, final float wizardModifier,
                final int baseDmg, final int baseIncrease) {
        super(baseDmg, baseIncrease);
        this.rogueModifier = rogueModifier;
        this.knightModifier = knightModifier;
        this.pyromancerModifier = pyromancerModifier;
        this.wizardModifier = wizardModifier;
        this.fieldModifier = 1.0f;
        this.player = p;
    }

    @Override
    public void visit(final Rogue target) {
        int dmg = Math.round(baseDmg * fieldModifier * rogueModifier);
        target.setUnracistDamageReceived(Math.round(baseDmg * fieldModifier));
        target.setHP(target.getHP() - dmg);
    }

    @Override
    public void visit(final Knight target) {

        int dmg = Math.round(baseDmg * fieldModifier * knightModifier);
        target.setUnracistDamageReceived(Math.round(baseDmg * fieldModifier));
        target.setHP(target.getHP() - dmg);

    }

    @Override
    public void visit(final Pyromancer target) {
        int dmg = Math.round(baseDmg * fieldModifier * pyromancerModifier);
        target.setUnracistDamageReceived(Math.round(baseDmg * fieldModifier));
        target.setHP(target.getHP() - dmg);
    }

    @Override
    public void visit(final Wizard target) {
        int dmg = Math.round(baseDmg * fieldModifier * wizardModifier);
        target.setUnracistDamageReceived(Math.round(baseDmg * fieldModifier));
        target.setHP(target.getHP() - dmg);
    }

    public void levelUp() {
        this.baseDmg += baseIncrease;
    }

    public float getFieldModifier() {
        return this.fieldModifier;
    }

    public void reset() {
        this.fieldModifier = 1.0f;
    }

    @Override
    public void visitField(final Land field) {
        this.fieldModifier = 1.0f;
    }

    @Override
    public void visitField(final Volcanic field) {
        fieldModifier = 1.25f;
    }

    @Override
    public void visitField(final Desert field) {
        this.fieldModifier = 1.0f;
    }

    @Override
    public void visitField(final Woods field) {
        this.fieldModifier = 1.0f;
    }
}
