package abilities;

import players.Knight;
import players.Pyromancer;
import players.Rogue;
import players.Wizard;

public interface PlayerVisitor {
    void visit(Rogue target);
    void visit(Knight target);
    void visit(Pyromancer target);
    void visit(Wizard target);


}
