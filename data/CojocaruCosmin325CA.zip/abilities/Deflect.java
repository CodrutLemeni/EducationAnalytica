package abilities;

import fields.*;
import players.*;

public class Deflect extends Ability {
    private float percent;
    private float percentIncrease;
    private float maxIncrease;
    private Player player;

    public Deflect(final Player p, final float rogueModifier, final float knightModifier,
                   final float pyromancerModifier, final int baseDmg, final int baseIncrease, final float percent,
                   final float percentIncrease, final float maxIncrease) {
        super(baseDmg, baseIncrease);
        this.rogueModifier = rogueModifier;
        this.knightModifier = knightModifier;
        this.pyromancerModifier = pyromancerModifier;
        this.percent = percent;
        this.percentIncrease = percentIncrease;
        this.maxIncrease = maxIncrease;
        this.player = p;
        this.fieldModifier = 1.0f;
    }

    @Override
    public void visit(final Rogue target) {
        Wizard p = new Wizard(player.getHP(), player.getXP(), player.getLvl(),
                player.getBonusHpLvl(), player.getX(), player.getY());
        target.getFirstAbility().visit(p);
        target.getSecondAbility().visit(p);
        int noRaceDmg = p.getUnracistDamageReceived();
        int dmg = Math.round(percent * noRaceDmg * fieldModifier * rogueModifier);
        target.getFirstAbility().setAppliedTimes(target.getFirstAbility().getAppliedTimes() - 1);
        target.setHP(target.getHP() - dmg);
    }

    @Override
    public void visit(final Knight target) {
        Wizard p = new Wizard(player.getMaxHp(), player.getXP(), player.getLvl(),
                player.getBonusHpLvl(), player.getX(), player.getY());
        target.getFirstAbility().visit(p);
        target.getSecondAbility().visit(p);
        int noRaceDmg = p.getUnracistDamageReceived();
        int dmg = Math.round(percent * noRaceDmg * fieldModifier * knightModifier);
        target.setHP(target.getHP() - dmg);
    }

    @Override
    public void visit(final Pyromancer target) {
        Wizard p = new Wizard(player.getHP(), player.getXP(), player.getLvl(),
                player.getBonusHpLvl(), player.getX(), player.getY());
        target.getFirstAbility().visit(p);
        target.getSecondAbility().visit(p);
        int noRaceDmg = p.getUnracistDamageReceived();
        int dmg = Math.round(percent * noRaceDmg * fieldModifier * pyromancerModifier);
        target.setHP(target.getHP() - dmg);
    }

    @Override
    public void visit(final Wizard target) {
        return;
    }

    public void levelUp() {
        this.percent = Math.min(percent + percentIncrease, maxIncrease);
    }

    public float getFieldModifier() {
        return this.fieldModifier;
    }

    public void reset() {
        this.fieldModifier = 1.0f;
    }

    @Override
    public void visitField(final Land field) {
        this.fieldModifier = 1.0f;
    }

    @Override
    public void visitField(final Volcanic field) {
        this.fieldModifier = 1.0f;
    }

    @Override
    public void visitField(final Desert field) {
        this.fieldModifier = 1.10f;

    }

    @Override
    public void visitField(final Woods field) {
        this.fieldModifier = 1.0f;
    }
}
