package abilities;

import players.Player;

public final class AbilitiesFactory {
    private static AbilitiesFactory instance = null;

    private static class FireblastSpecs {
        public static final float ROGUE_MODIFIER = 0.8f;
        public static final float KNIGHT_MODIFIER = 1.2f;
        public static final float PYROMANCER_MODIFIER = 0.9f;
        public static final float WIZARD_MODIFIER = 1.05f;
        public static final int BASE_DMG = 350;
        public static final int BASE_INCREASE = 50;

    }

    private static class IgniteSpecs {
        public static final float ROGUE_MODIFIER= 0.8f;
        public static final float KNIGHT_MODIFIER = 1.2f;
        public static final float PYROMANCER_MODIFIER = 0.9f;
        public static final float WIZARD_MODIFIER = 1.05f;
        public static final int BASE_DMG = 150;
        public static final int OVERTIME = 50;
        public static final int BASE_INCREASE = 20;
        public static final int OVERTIME_INCREASE = 30;
        public static final int ROUNDS_OVERTIME = 2;
    }

    private static class ExecuteSpecs {
        public static final float ROGUE_MODIFIER = 1.15f;
        public static final float KNIGHT_MODIFIER = 1.0f;
        public static final float PYROMANCER_MODIFIER = 1.1f;
        public static final float WIZARD_MODIFIER = 0.8f;
        public static final int BASE_DMG = 200;
        public static final int BASE_INCREASE = 30;
        public static final float HP_PERCENT = 0.2f;
        public static final float HP_PERCENT_INCREASE = 0.01f;
        public static final float MAX_HP_PERCENT = 0.4f;
    }

    private static class SlamSpecs{
        public static final float ROGUE_MODIFIER = 0.8f;
        public static final float KNIGHT_MODIFIER = 1.2f;
        public static final float PYROMANCER_MODIFIER = 0.9f;
        public static final float WIZARD_MODIFIER = 1.05f;
        public static final int BASE_DMG = 100;
        public static final int BASE_INCREASE = 40;
    }

    private static class DrainSpecs {
        public static final float ROGUE_MODIFIER = 0.8f;
        public static final float KNIGHT_MODIFIER = 1.2f;
        public static final float PYROMANCER_MODIFIER = 0.9f;
        public static final float WIZARD_MODIFIER = 1.05f;
        public static final float PERCENT = 0.2f;
        public static final float PERCENT_INCREASE = 0.05f;
        public static final float OPPONENT_HP_PERCENT = 0.3f;
    }

    private static class DeflectSpecs {
        public static final float ROGUE_MODIFIER = 1.2f;
        public static final float KNIGHT_MODIFIER = 1.4f;
        public static final float PYROMANCER_MODIFIER = 1.3f;
        public static final float PERCENT = 0.35f;
        public static final float PERCENT_INCREASE = 0.02f;
        public static final float MAX_PERCENT = 0.7f;

    }

    private static class BackstabSpecs {
        public static final float ROGUE_MODIFIER = 1.2f;
        public static final float KNIGHT_MODIFIER = 0.9f;
        public static final float PYROMANCER_MODIFIER = 1.25f;
        public static final float WIZARD_MODIFIER = 1.25f;
        public static final int BASE_DMG = 200;
        public static final int BASE_INCREASE = 20;
        public static final float CRITICAL_BONUS = 1.5f;

    }

    private static class ParalysisSpecs {
        public static final float ROGUE_MODIFIER = 0.9f;
        public static final float KNIGHT_MODIFIER = 0.8f;
        public static final float PYROMANCER_MODIFIER = 1.2f;
        public static final float WIZARD_MODIFIER = 1.25f;
        public static final int BASE_DMG = 40;
        public static final int BASE_INCREASE = 10;
        public static final int ROUNDS_OVERTIME = 3;
        public static final int ROUNDS_OVERTIME_WOODS = 6;
    }

    public Ability getAbility(String s, Player p) {
        if (s.equals("Fireblast")) {
            return new Fireblast(p, FireblastSpecs.ROGUE_MODIFIER, FireblastSpecs.KNIGHT_MODIFIER,
                    FireblastSpecs.PYROMANCER_MODIFIER, FireblastSpecs.WIZARD_MODIFIER,
                    FireblastSpecs.BASE_DMG, FireblastSpecs.BASE_INCREASE);
        } else if (s.equals("Ignite")) {
            return new Ignite(p, IgniteSpecs.ROGUE_MODIFIER, IgniteSpecs.KNIGHT_MODIFIER,
                    IgniteSpecs.PYROMANCER_MODIFIER, IgniteSpecs.WIZARD_MODIFIER,
                    IgniteSpecs.BASE_DMG, IgniteSpecs.BASE_INCREASE,
                    IgniteSpecs.OVERTIME, IgniteSpecs.OVERTIME_INCREASE,
                    IgniteSpecs.ROUNDS_OVERTIME);
        } else if (s.equals("Execute")) {
            return new Execute(p, ExecuteSpecs.ROGUE_MODIFIER, ExecuteSpecs.KNIGHT_MODIFIER,
                    ExecuteSpecs.PYROMANCER_MODIFIER, ExecuteSpecs.WIZARD_MODIFIER,
                    ExecuteSpecs.BASE_DMG, ExecuteSpecs.BASE_INCREASE, ExecuteSpecs.HP_PERCENT,
                    ExecuteSpecs.HP_PERCENT_INCREASE, ExecuteSpecs.MAX_HP_PERCENT);
        } else if (s.equals("Slam")) {
            return new Slam(p, SlamSpecs.ROGUE_MODIFIER, SlamSpecs.KNIGHT_MODIFIER,
                    SlamSpecs.PYROMANCER_MODIFIER, SlamSpecs.WIZARD_MODIFIER, SlamSpecs.BASE_DMG,
                    SlamSpecs.BASE_INCREASE);
        } else if (s.equals("Drain")) {
            return new Drain(p, DrainSpecs.ROGUE_MODIFIER, DrainSpecs.KNIGHT_MODIFIER,
                    DrainSpecs.PYROMANCER_MODIFIER, DrainSpecs.WIZARD_MODIFIER,
                    DrainSpecs.PERCENT, DrainSpecs.PERCENT_INCREASE, DrainSpecs.OPPONENT_HP_PERCENT);
        } else if (s.equals("Deflect")) {
            return new Deflect(p, DeflectSpecs.ROGUE_MODIFIER, DeflectSpecs.KNIGHT_MODIFIER,
                    DeflectSpecs.PYROMANCER_MODIFIER, 0, 0, DeflectSpecs.PERCENT,
                    DeflectSpecs.PERCENT_INCREASE, DeflectSpecs.MAX_PERCENT);
        } else if (s.equals("Backstab")) {
            return new Backstab(p, BackstabSpecs.ROGUE_MODIFIER, BackstabSpecs.KNIGHT_MODIFIER,
                    BackstabSpecs.PYROMANCER_MODIFIER, BackstabSpecs.WIZARD_MODIFIER, BackstabSpecs.BASE_DMG,
                    BackstabSpecs.BASE_INCREASE, BackstabSpecs.CRITICAL_BONUS);
        } else if (s.equals("Paralysis")) {
            return new Paralysis(p, ParalysisSpecs.ROGUE_MODIFIER, ParalysisSpecs.KNIGHT_MODIFIER,
                    ParalysisSpecs.PYROMANCER_MODIFIER, ParalysisSpecs.WIZARD_MODIFIER, ParalysisSpecs.BASE_DMG,
                    ParalysisSpecs.BASE_INCREASE, ParalysisSpecs.ROUNDS_OVERTIME);
        }
        return null;
    }

    public static AbilitiesFactory getInstance() {
        if (instance == null) {
            instance = new AbilitiesFactory();
        }
        return instance;
    }



}
