package abilities;

import fields.*;
import players.*;

public class Paralysis extends Ability {
    private float rogueModifier;
    private float knightModifier;
    private float pyromancerModifier;
    private float wizardModifier;
    private int overtimeDmg;
    private int overtimeRounds;
    private int overtimeIncrease;
    private int roundModifier;
    private Player player;

    public Paralysis(final Player p, final float rogueModifier, final float knightModifier,
                     final float pyromancerModifier, final float wizardModifier,
                     final int baseDmg, final int baseIncrease, final int overtimeRounds) {
        super(baseDmg, baseIncrease);
        this.rogueModifier = rogueModifier;
        this.knightModifier = knightModifier;
        this.pyromancerModifier = pyromancerModifier;
        this.wizardModifier = wizardModifier;
        this.fieldModifier = 1.0f;
        this.overtimeDmg = baseDmg;
        this.overtimeRounds = overtimeRounds;
        this.overtimeIncrease = baseIncrease;
        this.roundModifier = 1;
        this.player = p;
    }

    @Override
    public void visit(final Rogue target) {
        int dmg = Math.round(baseDmg * fieldModifier * rogueModifier);
        target.setHP(target.getHP() - dmg);
        int overtimeDamage = Math.round(overtimeDmg * fieldModifier * rogueModifier);
        target.setDmgOvertime(overtimeDamage);
        target.setRoundsOvertime(overtimeRounds * roundModifier);
        target.setUnmovedRounds(overtimeRounds * roundModifier);
        target.setCanMove(false);
    }

    @Override
    public void visit(final Knight target) {
        int dmg = Math.round(baseDmg * fieldModifier * knightModifier);
        target.setHP(target.getHP() - dmg);
        int overtimeDamage = Math.round(overtimeDmg * fieldModifier * knightModifier);
        target.setDmgOvertime(overtimeDamage);
        target.setRoundsOvertime(overtimeRounds * roundModifier);
        target.setUnmovedRounds(overtimeRounds * roundModifier);
        target.setCanMove(false);
    }

    @Override
    public void visit(final Pyromancer target) {
        int dmg = Math.round(baseDmg * fieldModifier * pyromancerModifier);
        target.setHP(target.getHP() - dmg);
        int overtimeDamage = Math.round(overtimeDmg * fieldModifier * pyromancerModifier);
        target.setDmgOvertime(overtimeDamage);
        target.setRoundsOvertime(overtimeRounds * roundModifier);
        target.setUnmovedRounds(overtimeRounds * roundModifier);
        target.setCanMove(false);
    }

    @Override
    public void visit(final Wizard target) {
        int dmg = Math.round(baseDmg * fieldModifier * wizardModifier);
        target.setHP(target.getHP() - dmg);
        int overtimeDamage = Math.round(overtimeDmg * fieldModifier * wizardModifier);
        target.setDmgOvertime(overtimeDamage);
        target.setRoundsOvertime(overtimeRounds * roundModifier);
        target.setUnmovedRounds(overtimeRounds * roundModifier);
        target.setUnracistDamageReceived(Math.round(baseDmg * fieldModifier));
        target.setCanMove(false);
    }

    public void levelUp() {
        this.baseDmg += baseIncrease;
        this.overtimeDmg = baseDmg;
    }

    public void reset() {
        this.fieldModifier = 1.0f;
        this.roundModifier = 1;
    }

    @Override
    public int getOvertimeRounds() {
        return overtimeRounds * roundModifier;
    }

    @Override
    public int getOvertimeDmg() {
        return overtimeDmg;
    }

    @Override
    public void visitField(final Land field) {
        this.fieldModifier = 1.0f;
    }

    @Override
    public void visitField(final Volcanic field) {
        this.fieldModifier = 1.0f;
    }

    @Override
    public void visitField(final Desert field) {
        this.fieldModifier = 1.0f;
    }

    @Override
    public void visitField(final Woods field) {
        fieldModifier = 1.15f;
        roundModifier = 2;
    }
}
