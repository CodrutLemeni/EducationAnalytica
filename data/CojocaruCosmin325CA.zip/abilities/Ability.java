package abilities;

import fields.FieldVisitor;
import players.*;

public abstract class Ability implements PlayerVisitor, FieldVisitor {
    protected int baseDmg;
    protected int baseIncrease;
    protected float rogueModifier;
    protected float knightModifier;
    protected float pyromancerModifier;
    protected float wizardModifier;
    protected float fieldModifier;
    protected int appliedTimes;
    private char lastHit;

    public Ability(int baseDmg, int dmgLevel) {
        this.baseDmg = baseDmg;
        this.baseIncrease = dmgLevel;
    }

    @Override
    public abstract void visit(Rogue target);

    @Override
    public abstract void visit(Knight target);

    @Override
    public abstract void visit(Pyromancer target);

    @Override
    public abstract void visit(Wizard target);

    public int getBaseDmg() {
        return baseDmg;
    }

    public void setBaseDmg(int baseDmg) {
        this.baseDmg = baseDmg;
    }

    public int getOvertimeRounds() {
        return 0;
    }
    public int getOvertimeDmg() {
        return 0;
    }

    public float getRogueModifier() {
        return 0;
    }

    public float getKnightModifier() {
        return 0;
    }

    public float getPyromancerModifier() {
        return 0;
    }

    public float getWizardModifier() {
        return 0;
    }

    public float getFieldModifier() {
        return 1.0f;
    }

    public int getAppliedTimes() {
        return appliedTimes;
    }

    public void setAppliedTimes(int appliedTimes) {
        this.appliedTimes = appliedTimes;
    }


    public abstract void levelUp();
    public abstract void reset();

}
