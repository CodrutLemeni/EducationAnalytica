package abilities;

import fields.Desert;
import fields.Land;
import fields.Volcanic;
import fields.Woods;
import players.*;

public class Execute extends Ability {
    private float hpPercent;
    private float hpPercentIncrease;
    private  float maxIncrease;
    private Player player;

    public Execute(final Player p, final float rogueModifier, final float knightModifier,
                   final float pyromancerModifier, final float wizardModifier,
                   final int baseDmg, final int baseIncrease, final float hpPercent,
                   final float hpPercentIncrease, final float maxIncrease) {
        super(baseDmg, baseIncrease);
        this.rogueModifier = rogueModifier;
        this.knightModifier = knightModifier;
        this.pyromancerModifier = pyromancerModifier;
        this.wizardModifier = wizardModifier;
        this.hpPercent = hpPercent;
        this.hpPercentIncrease = hpPercentIncrease;
        this.maxIncrease = maxIncrease;
        this.fieldModifier = 1.0f;
        this.player = p;
    }

    @Override
    public void visit(final Rogue target) {
        if (target.getHP() < hpPercent * target.getMaxHp()) {
            int dmg = target.getHP();
            target.setHP(0);
            return;
        }
        int dmg = Math.round(baseDmg * fieldModifier * rogueModifier);
        target.setHP(target.getHP() - dmg);
    }

    @Override
    public void visit(final Knight target) {
        if (target.getHP() < hpPercent * target.getMaxHp()) {
            int dmg = target.getHP();
            target.setHP(0);
            return;
        }
        int dmg = Math.round(baseDmg * fieldModifier * knightModifier);
        target.setUnracistDamageReceived(Math.round(baseDmg * fieldModifier));
        target.setHP(target.getHP() - dmg);
    }

    @Override
    public void visit(final Pyromancer target) {
        if (target.getHP() < hpPercent * target.getMaxHp()) {
            int dmg = target.getHP();
            target.setHP(0);
            return;
        }
        int dmg = Math.round(baseDmg * fieldModifier * pyromancerModifier);
        target.setUnracistDamageReceived(Math.round(baseDmg * fieldModifier));
        target.setHP(target.getHP() - dmg);
    }

    @Override
    public void visit(final Wizard target) {
        if (target.getHP() <= 0) {
            return;
        }
        if (target.getHP() < hpPercent * target.getMaxHp()) {
            int dmg = target.getHP();
            target.setHP(0);
            target.setUnracistDamageReceived(dmg);
            return;
        }
        int dmg = Math.round(baseDmg * fieldModifier * wizardModifier);
        target.setUnracistDamageReceived(Math.round(baseDmg * fieldModifier));
        target.setHP(target.getHP() - dmg);
    }

    public void levelUp() {
        this.baseDmg += baseIncrease;
        this.hpPercent = Math.min(maxIncrease, hpPercent + hpPercentIncrease);
    }

    public float getFieldModifier() {
        return this.fieldModifier;
    }

    public void reset() {
        this.fieldModifier = 1.0f;
    }

    @Override
    public void visitField(final Land field) {
        fieldModifier = 1.15f;
    }

    @Override
    public void visitField(final Volcanic field) {
        this.fieldModifier = 1.0f;
    }

    @Override
    public void visitField(final Desert field) {
        this.fieldModifier = 1.0f;
    }

    @Override
    public void visitField(final Woods field) {
        this.fieldModifier = 1.0f;
    }
}
