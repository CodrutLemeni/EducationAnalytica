package abilities;

import fields.Desert;
import fields.Land;
import fields.Volcanic;
import fields.Woods;
import players.*;

public class Backstab extends Ability {
    private float criticalPercent;
    private Player player;

    public Backstab(final Player p, final float rogueModifier, final float knightModifier,
                    final float pyromancerModifier, final float wizardModifier,
                    final int baseDmg, final int baseIncrease, final float criticalPercent) {
        super(baseDmg, baseIncrease);
        this.rogueModifier = rogueModifier;
        this.knightModifier = knightModifier;
        this.pyromancerModifier = pyromancerModifier;
        this.wizardModifier = wizardModifier;
        this.fieldModifier = 1.0f;
        this.criticalPercent = criticalPercent;
        this.appliedTimes = 0;
        this.player = p;
    }

    @Override
    public void visit(final Rogue target) {
        int dmg = 0;
        if (appliedTimes % 3 == 0 && fieldModifier != 1.0f) {
            dmg = Math.round(baseDmg * criticalPercent * fieldModifier * rogueModifier);

        } else {
            dmg = Math.round(baseDmg * fieldModifier * rogueModifier);
        }
        target.setHP(target.getHP() - dmg);
        appliedTimes++;
    }

    @Override
    public void visit(final Knight target) {
        int dmg = 0;
        if (appliedTimes % 3 == 0 && fieldModifier != 1.0f) {
            dmg = Math.round(baseDmg * criticalPercent * fieldModifier * knightModifier);
        } else {
            dmg = Math.round(baseDmg * fieldModifier * knightModifier);
        }
        target.setHP(target.getHP() - dmg);
        appliedTimes++;
    }

    @Override
    public void visit(final Pyromancer target) {
        int dmg = 0;
        if (appliedTimes % 3 == 0 && fieldModifier != 1.0f) {
            dmg = Math.round(baseDmg * criticalPercent * fieldModifier * pyromancerModifier);
        } else {
            dmg = Math.round(baseDmg * fieldModifier * pyromancerModifier);
        }
        target.setHP(target.getHP() - dmg);
        appliedTimes++;
    }

    @Override
    public void visit(final Wizard target) {
        int dmg = 0;
        if (appliedTimes % 3 == 0 && fieldModifier != 1.0f) {
            dmg = Math.round(baseDmg * criticalPercent * fieldModifier * wizardModifier);
            target.setUnracistDamageReceived(Math.round(baseDmg * criticalPercent * fieldModifier));
        } else {
            dmg = Math.round(baseDmg * fieldModifier * wizardModifier);
            target.setUnracistDamageReceived(Math.round(baseDmg * fieldModifier));
        }
        target.setHP(target.getHP() - dmg);
        appliedTimes++;
    }
    public void levelUp() {
        this.baseDmg += baseIncrease;
    }
    public void reset() {
        this.fieldModifier = 1.0f;
    }


    @Override
    public void visitField(final Land field) {
        this.fieldModifier = 1.0f;
    }

    @Override
    public void visitField(final Volcanic field) {
        this.fieldModifier = 1.0f;
    }

    @Override
    public void visitField(final Desert field) {
        this.fieldModifier = 1.0f;
    }

    @Override
    public void visitField(Woods field) {
        fieldModifier = 1.15f;
    }


    public int getAppliedTimes() {
        return appliedTimes;
    }

    public void setAppliedTimes(int appliedTimes) {
        this.appliedTimes = appliedTimes;
    }
}
